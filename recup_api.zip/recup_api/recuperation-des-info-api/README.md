# recuperation des info api
 script de recuperation et affichages des infos api
